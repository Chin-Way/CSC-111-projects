miles=float(input("How many mailes have you driven? ")) #ask user number of miles
gallons=float(input("How many gallons have you  used? ")) #ask user number of gallons used
MPG=miles/gallons #calculating MPG
print(f"Your car's MPG is {MPG}.") #print out MPG
